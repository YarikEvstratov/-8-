const gridItem = document.querySelectorAll('.grid__item');
const grid = document.querySelector('.grid');


function clickBtn(id) {
    grid.classList.toggle('active');
    for (let i = 0; i < gridItem.length; i++) {
        if (id == i) {
            gridItem[i].classList.toggle('active');
        } else {
            gridItem[i].classList.toggle('remove')
        }
    }
}

for (let i = 0; i < gridItem.length; i++) {
    gridItem[i].addEventListener('click', function () {
        clickBtn(i);
    })
}